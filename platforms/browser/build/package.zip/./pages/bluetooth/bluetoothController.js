(function(gScope){
	
	angular.module(gScope.AppNameId)
	.controller('bluetoothController', ['$rootScope','$scope','$log',init]);

	function init($rootScope,$scope,$log){

		$scope.chooseBluetooth = function(){
			
		}

	}

})