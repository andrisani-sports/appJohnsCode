(function(gScope){
	
angular.module(gScope.AppNameId)
	.controller('instructionsController', ['$scope','$log', 'chartService', init]);


function init($scope,$log,chartService){



}

})(this);