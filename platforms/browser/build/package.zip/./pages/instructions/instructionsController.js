(function(gScope){
	
angular.module(gScope.AppNameId)
	.controller('instructionsController', ['$scope','$log', 'chartService', 'bluetoothService', init]);


function init($scope,$log,chartService,bluetoothService){



}

})(this);